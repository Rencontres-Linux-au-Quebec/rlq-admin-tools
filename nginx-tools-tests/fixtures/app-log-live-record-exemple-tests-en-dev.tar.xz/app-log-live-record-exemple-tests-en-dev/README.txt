ENREGISTREMENT D'UN TEST — app-log-live.py
============================================================
Étiquette        : Tests en DEV
Début            : 2026-10-22 11:59:04 EDT  (2026-10-22 15:59:04 UTC)
Fin              : 2026-10-22 12:21:39 EDT  (2026-10-22 16:21:39 UTC)
Durée            : 1355 s — arrêt : touche R
Étapes           : 14 (steps.txt)
Serveur          : odoo-dev — Debian GNU/Linux 13 (trixie)
Programme        : app-log-live.py v1.97.20261022.100559 (composant _record.py v1.1.20261022.083937)
Lignes           : 355 gardées (records.log) ; 250 de bruit retirées (robots 3, fichiers statiques 245, websockets 2, sondes locales 0) — toutes dans stream-all.log
Confidentialité  : adresses IP, courriels, noms connus et jetons remplacés par des pseudonymes stables (les mêmes dans tous les fichiers) ;
                   littéraux SQL remplacés par '?' ; aucune donnée personnelle lue dans la base (compteurs, dates, identifiants, états).

Contenu :
  records.log     les lignes du test, sans le bruit
  steps.txt       les étapes marquées avec la touche N (début, fin, durée, description)
  stream-all.log  toutes les lignes, avec leur catégorie
  raw/            extraits complets des journaux pendant la fenêtre (nginx, fail2ban, Odoo, journal systemd du service)
  network/        connexions TCP des ports web et d'Odoo toutes les 10 s (ss), et leur compte par port
  db/             activité PostgreSQL et verrous sur ir_cron toutes les 10 s ; instantanés de début et de fin ; colonnes des tables
  context/        réglages du service, configuration d'Odoo (sans secret), modules, journaux surveillés
Sources absentes ou coupées : database base_exemple_neutre: unreadable for the start snapshot; database base_exemple_2_dev: unreadable for the start snapshot; PostgreSQL samples: unreachable (psql missing or not root); database base_exemple_neutre: unreadable for the end snapshot; database base_exemple_2_dev: unreadable for the end snapshot

TEST RECORDING — app-log-live.py
============================================================
Label            : Tests en DEV
Start            : 2026-10-22 11:59:04 EDT  (2026-10-22 15:59:04 UTC)
End              : 2026-10-22 12:21:39 EDT  (2026-10-22 16:21:39 UTC)
Duration         : 1355 s — stopped by: R key
Steps            : 14 (steps.txt)
Server           : odoo-dev — Debian GNU/Linux 13 (trixie)
Program          : app-log-live.py v1.97.20261022.100559 (component _record.py v1.1.20261022.083937)
Lines            : 355 kept (records.log); 250 noise lines removed (robots 3, static files 245, websockets 2, local probes 0) — all of them in stream-all.log
Privacy          : IP addresses, e-mails, known names and tokens replaced by stable pseudonyms (the same in every file);
                   SQL literals replaced by '?'; no personal data read from the database (counts, dates, identifiers, states).

Content:
  records.log     the lines of the test, without the noise
  steps.txt       the steps marked with the N key (start, end, duration, description)
  stream-all.log  every line, with its category
  raw/            complete log extracts of the window (nginx, fail2ban, Odoo, systemd journal of the service)
  network/        TCP connections of the web and Odoo ports every 10 s (ss), and their count per port
  db/             PostgreSQL activity and ir_cron locks every 10 s; start and end snapshots; columns of the tables
  context/        service settings, Odoo configuration (no secret), modules, watched logs
Missing or cut sources: database base_exemple_neutre: unreadable for the start snapshot; database base_exemple_2_dev: unreadable for the start snapshot; PostgreSQL samples: unreachable (psql missing or not root); database base_exemple_neutre: unreadable for the end snapshot; database base_exemple_2_dev: unreadable for the end snapshot
